package com.burger.service;

import java.util.List;

import com.burger.model.Pedido;

public interface PedidoService {

	public String registrarPedido(double totalPedido, String nombreCliente, String fechaPedido, boolean estadoPedido);

	public List<Pedido> listarPedidos();

	public Pedido listarPedidoPorId(int id);

	public String actualizarPedido(int id, double totalPedido, String nombreCliente, String fechaPedido,
			boolean estadoPedido);

	public String eliminarPedido(int id);
}