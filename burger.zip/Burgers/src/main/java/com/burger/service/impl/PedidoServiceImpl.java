package com.burger.service.impl;

import java.util.List;

import com.burger.dao.PedidoDao;
import com.burger.dao.impl.PedidoDaoImpl;
import com.burger.model.Pedido;
import com.burger.service.PedidoService;

public class PedidoServiceImpl implements PedidoService {

    private PedidoDao dao = new PedidoDaoImpl();

    @Override
    public String registrarPedido(double totalPedido, String nombreCliente, String fechaPedido, boolean estadoPedido) {
        return dao.insertaPedido(new Pedido(0, totalPedido, nombreCliente, fechaPedido, estadoPedido));
    }

    @Override
    public List<Pedido> listarPedidos() {
        return dao.listarPedidos();
    }

    @Override
    public Pedido listarPedidoPorId(int id) {
        return dao.listarPedidoPorId(id);
    }

    @Override
    public String actualizarPedido(int id, double totalPedido, String nombreCliente, String fechaPedido, boolean estadoPedido) {
        return dao.actualizarPedido(new Pedido(id, totalPedido, nombreCliente, fechaPedido, estadoPedido));
    }

    @Override
    public String eliminarPedido(int id) {
        return dao.eliminarPedido(id);
    }
    
}