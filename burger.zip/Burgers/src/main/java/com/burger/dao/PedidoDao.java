package com.burger.dao;

import java.util.List;

import com.burger.model.Pedido;

public interface PedidoDao {

    public String insertaPedido(Pedido pedido);
    
    public List<Pedido> listarPedidos();
    
    public Pedido listarPedidoPorId(int id);
    
    public String actualizarPedido(Pedido pedido);
    
    public String eliminarPedido(int id);
}