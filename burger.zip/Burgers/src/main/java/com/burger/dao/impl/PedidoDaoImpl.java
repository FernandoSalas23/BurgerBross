package com.burger.dao.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.burger.config.Conectar;
import com.burger.dao.PedidoDao;
import com.burger.model.Pedido;

public class PedidoDaoImpl implements PedidoDao {

    private Conectar conectar;

    public PedidoDaoImpl() {
        conectar = new Conectar();
    }

    @Override
    public String insertaPedido(Pedido pedido) {

        String resultado = null;
        Connection cn = conectar.getConexion();

        try {
            CallableStatement cs = cn.prepareCall("{call registrar_pedido(?,?,?,?)}");
            cs.setDouble(1, pedido.getTotalPedido());
            cs.setString(2, pedido.getNombreCliente());
            cs.setString(3, pedido.getFechaPedido());
            cs.setBoolean(4, pedido.isEstadoPedido());

            int res = cs.executeUpdate();
            resultado = res == 0 ? "No se registró el pedido." : "Se registró el pedido.";
            cs.close();
        } catch (Exception e) {
            resultado = e.getMessage();
        } finally {
            try {
                cn.close();
            } catch (SQLException e) {
                resultado = e.getMessage();
            }
        }
        return resultado;
    }

    @Override
    public List<Pedido> listarPedidos() {

        Connection cn = conectar.getConexion();
        List<Pedido> lista = new ArrayList<>();

        try {
            CallableStatement cs = cn.prepareCall("{call listar_pedidos()}");
            ResultSet rs = cs.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                pedido.setIdPedido(rs.getInt(1));
                pedido.setTotalPedido(rs.getDouble(2));
                pedido.setNombreCliente(rs.getString(3));
                pedido.setFechaPedido(rs.getString(4));
                pedido.setEstadoPedido(rs.getBoolean(5));
                lista.add(pedido);
            }
            rs.close();
            cs.close();
            cn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lista;
    }

    @Override
    public Pedido listarPedidoPorId(int id) {

        Pedido pedido = null;
        Connection cn = conectar.getConexion();

        try {
            CallableStatement cs = cn.prepareCall("{call listar_pedido_id(?)}");
            cs.setInt(1, id);
            ResultSet rs = cs.executeQuery();
            if (rs.next()) {
                pedido = new Pedido();
                pedido.setIdPedido(rs.getInt(1));
                pedido.setTotalPedido(rs.getDouble(2));
                pedido.setNombreCliente(rs.getString(3));
                pedido.setFechaPedido(rs.getString(4));
                pedido.setEstadoPedido(rs.getBoolean(5));
            }
            rs.close();
            cs.close();
            cn.close();
        } catch (Exception e) {
            System.out.println("Error al listar pedido por id: " + e.getMessage());
        }

        return pedido;
    }

    @Override
    public String actualizarPedido(Pedido pedido) {

        String resultado = null;
        Connection cn = conectar.getConexion();

        try {
            CallableStatement cs = cn.prepareCall("{call actualizar_pedido(?,?,?,?,?)}");
            cs.setInt(1, pedido.getIdPedido());
            cs.setDouble(2, pedido.getTotalPedido());
            cs.setString(3, pedido.getNombreCliente());
            cs.setString(4, pedido.getFechaPedido());
            cs.setBoolean(5, pedido.isEstadoPedido());

            int res = cs.executeUpdate();
            resultado = res == 0 ? "No se actualizó el pedido." : "Se actualizó el pedido.";
            cs.close();
        } catch (Exception e) {
            resultado = e.getMessage();
        } finally {
            try {
                cn.close();
            } catch (SQLException e) {
                resultado = e.getMessage();
            }
        }

        return resultado;
    }

    @Override
    public String eliminarPedido(int id) {

        String resultado = null;

        Connection cn = conectar.getConexion();

        try {
            CallableStatement cs = cn.prepareCall("{call eliminar_pedido(?)}");
            cs.setInt(1, id);

            int res = cs.executeUpdate();

            resultado = res == 0 ? "No se eliminó el pedido." : "Se eliminó el pedido.";
            cs.close();
        } catch (Exception e) {
            System.out.println("Error al eliminar pedido: " + e.getMessage());
        } finally {
            try {
                cn.close();
            } catch (SQLException e) {
                resultado = e.getMessage();
            }
        }

        return resultado;
    }

}