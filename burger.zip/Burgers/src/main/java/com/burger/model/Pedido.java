package com.burger.model;

public class Pedido {

    private int idPedido;
    private double totalPedido;
    private String nombreCliente;
    private String fechaPedido;
    private boolean estadoPedido;

    public Pedido() {}

    public Pedido(int idPedido, double totalPedido, String nombreCliente, String fechaPedido, boolean estadoPedido) {
        this.idPedido = idPedido;
        this.totalPedido = totalPedido;
        this.nombreCliente = nombreCliente;
        this.fechaPedido = fechaPedido;
        this.estadoPedido = estadoPedido;
    }

    public int getIdPedido() {
        return idPedido;
    }

    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    public double getTotalPedido() {
        return totalPedido;
    }

    public void setTotalPedido(double totalPedido) {
        this.totalPedido = totalPedido;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getFechaPedido() {
        return fechaPedido;
    }

    public void setFechaPedido(String fechaPedido) {
        this.fechaPedido = fechaPedido;
    }

    public boolean isEstadoPedido() {
        return estadoPedido;
    }

    public void setEstadoPedido(boolean estadoPedido) {
        this.estadoPedido = estadoPedido;
    }

    @Override
    public String toString() {
        return "Pedido [idPedido=" + idPedido + ", totalPedido=" + totalPedido + 
                ", nombreCliente=" + nombreCliente + ", fechaPedido=" + fechaPedido + 
                ", estadoPedido=" + estadoPedido + "]";
    }
}