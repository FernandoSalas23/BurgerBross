package com.burger.config;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conectar {

	public Connection getConexion() {
		Connection cn = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			cn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/burgerbros?characterEncoding=latin1", 
					"root", "Jazmine_22");
		} catch (Exception e) {
			System.out.println("Error conectar Base de Datos: " + e.getMessage());
			e.printStackTrace();
		}
		
		return cn;
	}
}